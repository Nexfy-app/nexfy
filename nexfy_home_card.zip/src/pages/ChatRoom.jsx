import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Send, Paperclip, Image, Phone, X, CheckCheck, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { useTypingIndicator } from '@/hooks/useTypingIndicator';
import { useChatSound } from '@/hooks/useChatSound';
import TypingIndicator from '@/components/chat/TypingIndicator';

function MessageBubble({ msg, isMe }) {
  const time = msg.created_date
    ? new Date(msg.created_date).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    : '';

  return (
    <motion.div
      initial={{ opacity: 0, y: 6, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className={cn("flex mb-1.5", isMe ? "justify-end" : "justify-start")}
    >
      <div className={cn(
        "max-w-[78%] rounded-2xl px-3.5 py-2.5 shadow-sm",
        isMe
          ? "bg-foreground text-white rounded-br-md"
          : "bg-white text-foreground rounded-bl-md border border-slate-100"
      )}>
        {msg.message_type === 'image' && msg.file_url && (
          <img src={msg.file_url} alt="imagem" className="rounded-xl max-w-full max-h-52 object-cover mb-1.5" />
        )}
        {msg.message_type === 'file' && msg.file_url && (
          <a href={msg.file_url} target="_blank" rel="noreferrer"
            className="flex items-center gap-2 py-1 hover:opacity-80">
            <div className={cn("w-8 h-8 rounded-xl flex items-center justify-center", isMe ? "bg-white/15" : "bg-slate-100")}>
              <Paperclip className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-medium underline truncate max-w-[140px]">{msg.file_name || 'arquivo'}</span>
          </a>
        )}
        {msg.message && (
          <p className="text-sm leading-relaxed">{msg.message}</p>
        )}
        <div className={cn("flex items-center justify-end gap-1 mt-1", isMe ? "text-white/40" : "text-muted-foreground")}>
          <span className="text-[10px]">{time}</span>
          {isMe && (
            msg.is_read
              ? <CheckCheck className="w-3 h-3 text-blue-400" />
              : <Check className="w-3 h-3 opacity-60" />
          )}
        </div>
      </div>
    </motion.div>
  );
}

function DateDivider({ label }) {
  return (
    <div className="flex items-center gap-2 my-3">
      <div className="flex-1 h-px bg-slate-200" />
      <span className="text-[10px] text-muted-foreground font-medium bg-transparent px-2">{label}</span>
      <div className="flex-1 h-px bg-slate-200" />
    </div>
  );
}

function groupMessagesByDate(messages) {
  const groups = [];
  let lastDate = null;
  messages.forEach(msg => {
    if (!msg.created_date) return;
    const d = new Date(msg.created_date);
    const label = d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
    if (label !== lastDate) {
      groups.push({ type: 'divider', label });
      lastDate = label;
    }
    groups.push({ type: 'msg', msg });
  });
  return groups;
}

export default function ChatRoom() {
  const requestId = window.location.pathname.split('/chat/')[1];
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [showAttach, setShowAttach] = useState(false);
  const [otherUserTyping, setOtherUserTyping] = useState(false);
  const scrollRef = useRef(null);
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isTyping, setTypingTrue } = useTypingIndicator(requestId, user?.email);
  const { playSound } = useChatSound();
  const lastMessageCountRef = useRef(0);

  useEffect(() => { base44.auth.me().then(setUser); }, []);

  const { data: messages = [] } = useQuery({
    queryKey: ['chat-messages', requestId],
    queryFn: () => base44.entities.ChatMessage.filter({ service_request_id: requestId }, 'created_date'),
    enabled: !!requestId,
    refetchInterval: 2000,
  });

  const { data: request } = useQuery({
    queryKey: ['chat-request', requestId],
    queryFn: async () => {
      const r = await base44.entities.ServiceRequest.filter({ id: requestId });
      return r[0];
    },
    enabled: !!requestId,
  });

  const { data: proData } = useQuery({
    queryKey: ['pro-for-chat', request?.professional_id],
    queryFn: () => base44.entities.Professional.filter({ id: request.professional_id }),
    enabled: !!request?.professional_id,
  });

  const otherPro = proData?.[0];

  // Mark received messages as read and play sound
  useEffect(() => {
    if (!user || !messages.length) return;
    const newMessages = messages.slice(lastMessageCountRef.current);
    const unread = messages.filter(m => m.receiver_email === user.email && !m.is_read);
    
    // Toca som apenas para novas mensagens recebidas
    if (newMessages.length > 0 && newMessages.some(m => m.sender_email !== user.email && !m._optimistic)) {
      playSound();
    }
    
    lastMessageCountRef.current = messages.length;
    unread.forEach(m => {
      base44.entities.ChatMessage.update(m.id, { is_read: true }).catch(() => {});
    });
  }, [messages, user, playSound]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Simular indicador de digitação do outro usuário
  useEffect(() => {
    if (messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.sender_email !== user?.email) {
        setOtherUserTyping(true);
        const timer = setTimeout(() => setOtherUserTyping(false), 2000);
        return () => clearTimeout(timer);
      }
    }
  }, [messages, user?.email]);

  const getReceiverEmail = () => {
    if (!request || !user) return '';
    if (request.client_email === user.email) return otherPro?.user_email || '';
    return request.client_email;
  };

  const sendMessage = async (content, type = 'text', fileUrl = null, fileName = null) => {
    const receiverEmail = getReceiverEmail();
    const optimisticMsg = {
      id: `opt-${Date.now()}`,
      service_request_id: requestId,
      sender_email: user.email,
      receiver_email: receiverEmail,
      message: content || '',
      message_type: type,
      file_url: fileUrl,
      file_name: fileName,
      is_read: false,
      created_date: new Date().toISOString(),
      _optimistic: true,
    };

    // Optimistic update
    queryClient.setQueryData(['chat-messages', requestId], (old = []) => [...old, optimisticMsg]);
    setSending(true);

    await base44.entities.ChatMessage.create({
      service_request_id: requestId,
      sender_email: user.email,
      receiver_email: receiverEmail,
      message: content || '',
      message_type: type,
      file_url: fileUrl,
      file_name: fileName,
      is_read: false,
    });

    // Email de notificação é enviado automaticamente via automação de backend
    queryClient.invalidateQueries({ queryKey: ['chat-messages', requestId] });
    setSending(false);
  };

  const handleSend = async () => {
    if (!message.trim() || sending) return;
    const text = message.trim();
    setMessage('');
    setTypingTrue();
    await sendMessage(text, 'text');
  };

  const handleInputChange = (e) => {
    setMessage(e.target.value);
    setTypingTrue();
  };

  const handleFileUpload = async (e, type) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setShowAttach(false);
    toast.loading('Enviando...');
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    toast.dismiss();
    await sendMessage('', type, file_url, file.name);
  };

  const otherName = request
    ? (request.client_email === user?.email ? request.professional_name : request.client_name)
    : 'Chat';

  const otherPhone = request?.client_email === user?.email ? otherPro?.phone : null;
  const grouped = groupMessagesByDate(messages);

  const unreadCount = messages.filter(m => m.receiver_email === user?.email && !m.is_read).length;

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <div
        className="px-4 pt-safe shrink-0"
        style={{ background: 'rgba(255,255,255,0.95)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(0,0,0,0.06)', boxShadow: '0 1px 12px rgba(0,0,0,0.06)' }}
      >
        <div className="flex items-center gap-3 py-3">
          <button
            onClick={() => navigate('/chat')}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-100 transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="w-10 h-10 rounded-full bg-foreground flex items-center justify-center font-bold text-sm text-white shrink-0 shadow-sm">
            {otherName?.charAt(0)?.toUpperCase()}
          </div>

          <div className="flex-1 min-w-0">
            <p className="font-bold text-sm truncate text-foreground">{otherName}</p>
            <p className="text-[10px] text-muted-foreground capitalize">
              {request?.category?.startsWith('outros:') ? request.category.replace('outros:', '') : request?.category?.replace(/_/g, ' ')} · {request?.status === 'in_progress' ? '🟢 Em andamento' : request?.status === 'completed' ? '✅ Concluído' : '⏳ Aguardando'}
            </p>
          </div>

          {otherPhone && (
            <a
              href={`tel:${otherPhone}`}
              className="w-9 h-9 flex items-center justify-center rounded-full bg-slate-100 hover:bg-slate-200 transition"
            >
              <Phone className="w-4 h-4 text-foreground" />
            </a>
          )}
        </div>
      </div>

      {/* Status banner — guia o usuário */}
      {request && (
        <>
          <div className={`border-b px-4 py-2.5 shrink-0 ${
            request.status === 'pending' ? 'bg-amber-50 border-amber-100' :
            request.status === 'accepted' ? 'bg-blue-50 border-blue-100' :
            request.status === 'in_progress' ? 'bg-indigo-50 border-indigo-100' :
            request.status === 'completed' ? 'bg-green-50 border-green-100' :
            'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <span className="text-base shrink-0">
                  {request.status === 'pending' ? '⏳' :
                   request.status === 'accepted' ? '✅' :
                   request.status === 'in_progress' ? '🔧' :
                   request.status === 'completed' ? '🎉' : '❌'}
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-foreground">
                    {request.status === 'pending' ? 'Aguardando confirmação do profissional...' :
                     request.status === 'accepted' ? 'Pedido aceito! Aguarde o profissional chegar.' :
                     request.status === 'in_progress' ? 'Serviço em andamento.' :
                     request.status === 'completed' ? 'Serviço concluído! Avalie o profissional.' :
                     'Pedido cancelado.'}
                  </p>
                  <p className="text-[9px] text-muted-foreground mt-0.5">
                    O SERV não processa pagamentos — pague diretamente ao profissional.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                {request.status === 'completed' && request.client_email === user?.email && (
                  <button
                    onClick={() => navigate(`/review/${request.id}`)}
                    className="flex items-center gap-1 bg-amber-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full hover:bg-amber-600 transition"
                  >
                    ★ Avaliar
                  </button>
                )}
              </div>
            </div>

          </div>

          {/* Tip for clients before acceptance */}
          {request.status === 'pending' && request.client_email === user?.email && (
            <div className="bg-blue-50 border-b border-blue-100 px-4 py-2.5 shrink-0">
              <div className="flex items-start gap-2">
                <span className="text-sm mt-0.5">📸</span>
                <div className="flex-1 min-w-0">
                  <p className="text-[11px] font-bold text-blue-900">Envie fotos do problema!</p>
                  <p className="text-[10px] text-blue-700 mt-0.5">Clique no ícone de anexo abaixo para enviar fotos. Isso ajuda o profissional a fazer um orçamento mais preciso.</p>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {grouped.map((item, i) =>
          item.type === 'divider'
            ? <DateDivider key={`d-${i}`} label={item.label} />
            : <MessageBubble key={item.msg.id} msg={item.msg} isMe={item.msg.sender_email === user?.email} />
        )}
        {otherUserTyping && (
          <div className="py-2">
            <TypingIndicator name={request?.client_email === user?.email ? request?.professional_name : request?.client_name} />
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Attach panel */}
      <AnimatePresence>
        {showAttach && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 16 }}
            className="bg-white border-t border-slate-100 px-4 py-3 flex flex-col gap-3 shrink-0"
          >
            <div className="flex gap-4">
              <label className="flex flex-col items-center gap-1.5 cursor-pointer flex-1">
                <input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleFileUpload(e, 'image')} />
                <div className="w-14 h-14 rounded-2xl bg-purple-50 border-2 border-purple-200 flex items-center justify-center hover:border-purple-400 transition">
                  <Image className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-[11px] text-foreground font-semibold">Foto</span>
                <span className="text-[9px] text-muted-foreground">do problema/local</span>
              </label>
              <label className="flex flex-col items-center gap-1.5 cursor-pointer flex-1">
                <input ref={fileInputRef} type="file" className="hidden" onChange={(e) => handleFileUpload(e, 'file')} />
                <div className="w-14 h-14 rounded-2xl bg-blue-50 border-2 border-blue-200 flex items-center justify-center hover:border-blue-400 transition">
                  <Paperclip className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-[11px] text-foreground font-semibold">Arquivo</span>
                <span className="text-[9px] text-muted-foreground">PDF, documento...</span>
              </label>
              <button onClick={() => setShowAttach(false)} className="self-start mt-1 text-muted-foreground hover:text-foreground transition">
                <X className="w-5 h-5" />
              </button>
            </div>
            {request?.status === 'pending' && request.client_email === user?.email && (
              <div className="text-[10px] text-blue-700 bg-blue-50 border border-blue-100 rounded-lg px-2.5 py-1.5">
                💡 <strong>Dica:</strong> Fotos do problema ajudam o profissional a fazer um orçamento mais preciso antes de aceitar.
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input bar */}
      <div className="bg-white border-t border-slate-100 px-3 py-2 shrink-0" style={{ paddingBottom: 'calc(8px + env(safe-area-inset-bottom, 0px))', boxShadow: '0 -1px 12px rgba(0,0,0,0.04)' }}>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAttach(!showAttach)}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-slate-100 transition text-muted-foreground"
          >
            <Paperclip className="w-4.5 h-4.5" style={{ width: '18px', height: '18px' }} />
          </button>

          <div className="flex-1 bg-slate-100 rounded-full px-4 py-2 min-h-[40px] flex items-center">
            <input
              value={message}
              onChange={handleInputChange}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
              placeholder="Mensagem..."
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            {isTyping && (
              <span className="text-[8px] text-muted-foreground ml-1 px-1">digitando...</span>
            )}
          </div>

          <button
            onClick={handleSend}
            disabled={!message.trim() || sending}
            className="w-9 h-9 bg-foreground text-white rounded-full flex items-center justify-center transition disabled:opacity-30 shadow-sm"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}