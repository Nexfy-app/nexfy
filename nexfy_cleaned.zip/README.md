# Nexfy

Projeto Nexfy configurado para desenvolvimento com Vercel, GitHub e Supabase.
